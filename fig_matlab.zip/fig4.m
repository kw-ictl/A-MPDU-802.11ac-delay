% ==================================
% A-MPDU aggregation with optimal number of MPDUs for delay requirements in IEEE 802.11ac
% Won Hyoung Lee and Ho Young Hwang
% 
% Copyright (c) <2019>
% Won Hyoung Lee and Ho Young Hwang
% All rights reserved.
% ==================================

colorAnal = [249, 249, 121] ./ 255;
colorSim = [74, 107, 219] ./ 255;

avgDelayAnal = [79.9289, 139.0048, 208.966];
avgDelaySim = [73.9777, 131.4688, 202.3486];
stdDelaySim = [0.9053, 1.2828, 5.7417];

figure;
b = bar([avgDelayAnal; avgDelaySim]');
b(1).FaceColor = colorAnal;
b(2).FaceColor = colorSim;
hold on 
for i = 1:3
    errorbar(i + 0.145, avgDelaySim(i), stdDelaySim(i), 'r', 'CapSize', 12);
end
legend('location', 'NorthWest' ...
    , '(Anal) Proposed method' ...
    , '(Sim) Proposed method' ...
    );

ylabel('Average delay [msec]');
set(gca, 'XTickLabel',{'Class 1', 'Class 2', 'Class 3'});
size = [1750 1312];
res = 300;
set(gcf,'paperunits','inches','paperposition',[0 0 size/res]);
print('ns3-figure/Fig4.tif','-dtiff',['-r' num2str(res)]);