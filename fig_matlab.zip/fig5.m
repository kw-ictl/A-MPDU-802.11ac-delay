% ==================================
% A-MPDU aggregation with optimal number of MPDUs for delay requirements in IEEE 802.11ac
% Won Hyoung Lee and Ho Young Hwang
% 
% Copyright (c) <2019>
% Won Hyoung Lee and Ho Young Hwang
% All rights reserved.
% ==================================

colorProposedMethod = [249, 249, 121] ./ 255;
colorMaximumAggregation = [74, 107, 219] ./ 255;

avgViolationRateProp = [0.0668, 0.0406, 0.0341, 0.0537];
avgViolationRateMax = [0.1937, 0.0388, 0.0162, 0.0837];
stdViolationRateProp = [0.0018, 0.0041, 0.0066, 0.0019];
stdViolationRateMax = [0.0045, 0.0023, 0.0046, 0.0014];

figure;
b = bar([avgViolationRateProp; avgViolationRateMax]');
b(1).FaceColor = colorProposedMethod;
b(2).FaceColor = colorMaximumAggregation;
hold on 
for i = 1:4
    errorbar(i - 0.148, avgViolationRateProp(i), stdViolationRateProp(i), 'm', 'CapSize', 12);
    errorbar(i + 0.148, avgViolationRateMax(i), stdViolationRateMax(i), 'r', 'CapSize', 12);
end

legend('location', 'NorthEast' ...
    , 'Proposed method' ...
    , 'Max aggergation method' ...
    );

ylabel('Violation rate on target delay');
set(gca, 'XTickLabel',{'Class 1', 'Class 2', 'Class 3', 'Avg.'});
size = [1750 1312];
res = 300;
set(gcf,'paperunits','inches','paperposition',[0 0 size/res]);
print('ns3-figure/Fig5.tif','-dtiff',['-r' num2str(res)]);
