% ==================================
% A-MPDU aggregation with optimal number of MPDUs for delay requirements in IEEE 802.11ac
% Won Hyoung Lee and Ho Young Hwang
% 
% Copyright (c) <2019>
% Won Hyoung Lee and Ho Young Hwang
% All rights reserved.
% ==================================

colorProposedMethod = [249, 249, 121] ./ 255;
colorMaximumAggregation = [74, 107, 219] ./ 255;

avgViolationRateProp = [0.0658, 0.04, 0.0327, 0.0527];
avgViolationRateMax = [0.187, 0.0423, 0.0156, 0.0823];
stdViolationRateProp = [0.0024, 0.0033, 0.0052, 0.0014];
stdViolationRateMax = [0.0068, 0.0042, 0.003, 0.0017];

figure;
b = bar([avgViolationRateProp; avgViolationRateMax]');
b(1).FaceColor = colorProposedMethod;
b(2).FaceColor = colorMaximumAggregation;
hold on 
for i = 1:4
    errorbar(i - 0.148, avgViolationRateProp(i), stdViolationRateProp(i), 'm', 'CapSize', 12);
    errorbar(i + 0.148, avgViolationRateMax(i), stdViolationRateMax(i), 'r', 'CapSize', 12);
end

legend('location', 'NorthEast' ...
    , 'Proposed method' ...
    , 'Max aggergation method' ...
    );

ylabel('Violation rate on target delay');
set(gca, 'XTickLabel',{'Class 1', 'Class 2', 'Class 3', 'Avg.'});
size = [1750 1312];
res = 300;
set(gcf,'paperunits','inches','paperposition',[0 0 size/res]);
print('ns3-figure/Fig7.tif','-dtiff',['-r' num2str(res)]);
