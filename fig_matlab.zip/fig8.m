% ==================================
% A-MPDU aggregation with optimal number of MPDUs for delay requirements in IEEE 802.11ac
% Won Hyoung Lee and Ho Young Hwang
% 
% Copyright (c) <2019>
% Won Hyoung Lee and Ho Young Hwang
% All rights reserved.
% ==================================

colorProposedMethod = [249, 249, 121] ./ 255;
colorMaximumAggregation = [74, 107, 219] ./ 255;
colorAmsduAggregation = [105, 210, 210] ./ 255;
colorDefaultAggregation = [34, 34, 117] ./ 255;

avgViolationRateProp = [0.0515, 0.0506, 0.0555, 0.0525];
stdViolationRateProp = [0.0036, 0.0044, 0.0039, 0.0021];
avgViolationRateMax = [0.1274, 0.1224, 0.1281, 0.1256];
stdViolationRateMax = [0.0086, 0.0091, 0.0151, 0.0034];

avgViolationRateAmsdu = [0.0288, 0.0293, 0.0274, 0.0285];
stdViolationRateAmsdu = [0.0049, 0.0035, 0.0039, 0.0023];
avgViolationRateDefault = [0.0903, 0.0911, 0.086, 0.089];
stdViolationRateDefault = [0.005, 0.0118, 0.007, 0.0035];

figure;
b = bar([avgViolationRateProp; avgViolationRateMax; avgViolationRateAmsdu; avgViolationRateDefault]');
b(1).FaceColor = colorProposedMethod;
b(2).FaceColor = colorMaximumAggregation;
b(3).FaceColor = colorAmsduAggregation;
b(4).FaceColor = colorDefaultAggregation;

hold on 
for i = 1:4
    errorbar(i - 0.27, avgViolationRateProp(i), stdViolationRateProp(i), 'r', 'CapSize', 12);
    errorbar(i - 0.09, avgViolationRateMax(i), stdViolationRateMax(i), 'color', [0.4 0.8 0], 'CapSize', 12);
    errorbar(i + 0.09, avgViolationRateAmsdu(i), stdViolationRateAmsdu(i), 'm', 'CapSize', 12);
    errorbar(i + 0.27, avgViolationRateDefault(i), stdViolationRateDefault(i), 'c', 'CapSize', 12);
end

legend('location', 'NorthEast' ...
    , 'Proposed method' ...
    , 'Max aggergation method' ...
    , 'A-MSDU with max length in IEEE 802.11' ...
    , 'A-MPDU with default length in NS-3' ...
    );

ylim([0, 0.2])
ylabel('Violation rate on target delay');
set(gca, 'XTickLabel',{'Class 1', 'Class 2', 'Class 3', 'Avg.'});
size = [1750 1312];
res = 300;
set(gcf,'paperunits','inches','paperposition',[0 0 size/res]);
print('ns3-figure/Fig8.tif','-dtiff',['-r' num2str(res)]);