% ==================================
% A-MPDU aggregation with optimal number of MPDUs for delay requirements in IEEE 802.11ac
% Won Hyoung Lee and Ho Young Hwang
% 
% Copyright (c) <2019>
% Won Hyoung Lee and Ho Young Hwang
% All rights reserved.
% ==================================

colorProposedMethod = [249, 249, 121] ./ 255;
colorMaximumAggregation = [74, 107, 219] ./ 255;
colorDefaultAggregation = [34, 34, 117] ./ 255;
colorAmsduAggregation = [105, 210, 210] ./ 255;

avgThroughputProp = [15.8786, 15.9904, 15.5075, 47.3765];
avgThroughputMax = [15.203, 15.2225, 14.8977, 45.3231];
avgThroughputAmsdu = [14.8645, 14.8324, 14.9891, 44.686];
avgThroughputDefault = [15.5015, 15.5523, 15.7583, 46.8121];

stdThroughputProp = [0.255, 0.2883, 0.2014, 0.1036];
stdThroughputMax = [0.5767, 0.6647, 0.9623, 0.1746];
stdThroughputAmsdu = [0.2421, 0.1981, 0.2108, 0.1073];
stdThroughputDefault = [0.4905, 0.7, 0.4435, 0.1791];


figure;
b = bar([avgThroughputProp; avgThroughputMax; avgThroughputAmsdu; avgThroughputDefault]');
b(1).FaceColor = colorProposedMethod;
b(2).FaceColor = colorMaximumAggregation;
b(3).FaceColor = colorAmsduAggregation;
b(4).FaceColor = colorDefaultAggregation;

hold on 
for i = 1:4
    errorbar(i - 0.27, avgThroughputProp(i), stdThroughputProp(i), 'r', 'CapSize', 12);
    errorbar(i - 0.09, avgThroughputMax(i), stdThroughputMax(i), 'color', [0.4 0.8 0], 'CapSize', 12);
    errorbar(i + 0.09, avgThroughputAmsdu(i), stdThroughputAmsdu(i), 'm', 'CapSize', 12);
    errorbar(i + 0.27, avgThroughputDefault(i), stdThroughputDefault(i), 'c', 'CapSize', 12);
end

legend('location', 'northwest' ...
    , 'Proposed method' ...
    , 'Max aggergation method' ...
    , 'A-MSDU with max length in IEEE 802.11' ...
    , 'A-MPDU with default length in NS-3' ...
    );

ylabel('Throughput [Mbps]');
set(gca, 'XTickLabel',{'Class 1', 'Class 2', 'Class 3', 'System'});
size = [1750 1312];
res = 300;
set(gcf,'paperunits','inches','paperposition',[0 0 size/res]);
print('ns3-figure/Fig9.tif','-dtiff',['-r' num2str(res)]);